#include "Queue.h"
#include "fatal.h"
#include <stdlib.h>

#define MinQueueSize ( 1 )

struct QueueRecord
{
    int Capacity;
    int Front;
    int Rear;
    int Size;
    ElementType *Array;
};

int isEmpty( Queue Q ){
    return Q->Size == 0;
}

int isFull( Queue Q ){
    return Q->Size == Q->Capacity;
}

Queue createQueue( int MaxElements ){
    Queue Q;
    if( MaxElements < MinQueueSize )
        Error( "Queue size is too small" );

    Q = malloc( sizeof( struct QueueRecord ) );
    if( Q == NULL )
        FatalError( "Out of space!!!" );

    Q->Array = malloc( sizeof( ElementType ) * MaxElements );
    if( Q->Array == NULL )
        FatalError( "Out of space!!!" );
    Q->Capacity = MaxElements;
    makeEmpty( Q );

    return Q;
}


void makeEmpty( Queue Q ){
    Q->Size = 0;
    Q->Front = 1;
    Q->Rear = 0;
}

static int Succ( int Value, Queue Q ){
    if( ++Value == Q->Capacity )
        Value = 0;
        return Value;
}

void enqueue( ElementType X, Queue Q ){
    if( isFull( Q ) )
        Error( "Full queue" );
    else{
        Q->Size++;
        Q->Rear = Succ( Q->Rear, Q );
        Q->Array[ Q->Rear ] = X;
    }
}

ElementType front( Queue Q ){
    if( !isEmpty( Q ) )
        return Q->Array[ Q->Front ];
        Error( "Empty queue" );
    return 0;  /* Return value used to avoid warning */
}

void dequeue( Queue Q ){
    if( isEmpty( Q ) )
        Error( "Empty queue" );
    else{
        Q->Size--;
        Q->Front = Succ( Q->Front, Q );
    }
}