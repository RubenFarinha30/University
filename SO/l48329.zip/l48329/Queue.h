 typedef int ElementType;
#ifndef _Queue_h
#define _Queue_h

struct QueueRecord;
typedef struct QueueRecord *Queue;

int isEmpty( Queue Q );
int isFull( Queue Q );
Queue createQueue( int MaxElements );
void makeEmpty( Queue Q );
void enqueue( ElementType X, Queue Q );
ElementType front( Queue Q );
void dequeue( Queue Q );

#endif