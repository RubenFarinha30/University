#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Queue.h"

typedef struct
{
    struct QueueRecord *BLCK;
    struct QueueRecord *READY;
}SO;

typedef struct
{
    int state;
    int position;
    int start;
    int all_times[9];
    int CPU;
}PROCESS;

#define RUN 1
#define BLCK -1
#define READY -2
#define EXIT 2

void processStart(int input[][8], int sz1, PROCESS *p){

    for (int proc = 0; proc < sz1; proc++)
        p[proc].start = input[proc][0];         
}

void processTimes(int input[][8], int num_of_proc, PROCESS *p){

    int proc=0;
    while (proc<num_of_proc)
    {
        int pos=1;
        while (input[proc][pos] != 0)
        {
            p[proc].all_times[pos-1]=input[proc][pos];
            pos++;
        }
        for (int i = pos-1; i < 9; i++)
            p[proc].all_times[i] = -1;

        proc++;
    }
    
}


int isExited(PROCESS *p, int number_of_process){

    int value=1;

    for (int proc = 0; proc < number_of_process; ++proc)
    {
        if (p[proc].state!=EXIT)
            value=0;
    }

    return value;

}

int isStartInstant(int time, int num_proc, PROCESS *p){
    
    if (p[num_proc].start == time)
        return 1;
    else
        return 0;
}

int isReady(Queue Ready, PROCESS *p){

    if (p->CPU == -5)
        return 1;
    else
        return 0;
}

char *algo_FCFS(int time, int number_of_process, Queue Block, Queue Ready, PROCESS *p){

    char *line = malloc(sizeof(char)*100);

    for (int proc = 0; proc < number_of_process; proc++)
    {
        if (isStartInstant(time,proc,p)){
            strcat(line,"NEW     ");
            p[proc].state=READY;
            enqueue(proc,Ready);
        }
        else if(time!=p[proc].start && p[proc].start>time){
            strcat(line,"             ");
        }
        else{

            if (p[proc].all_times[p[proc].position] == 0)
            {
                
                if (p[proc].position%2 == 0)
                {
                    dequeue(Ready);
                    enqueue(proc,Block);
                    p[proc].state=BLCK;
                    p->CPU=-5;
                }
                else
                {
                    dequeue(Block);
                    enqueue(proc,Ready);
                    p[proc].state=READY;
                }
                p[proc].position+=1;
            }

            if (p[proc].all_times[p[proc].position]!=-1)
            {
                if (isEmpty(Ready) )
                {
                    strcat(line,"BLCK      ");
                    p[proc].state == BLCK;
                    p[proc].all_times[p[proc].position]-=1;
                }
                else if (isReady(Ready,p) && front(Ready)==proc)
                {
                    p->CPU=proc;    
                    strcat(line,"RUN       ");
                    p[proc].state=RUN;
                    p[proc].all_times[p[proc].position]-=1;
                }
                else if (p->CPU == proc)
                {
                    strcat(line,"RUN       ");
                    p[proc].state=RUN;
                    p[proc].all_times[p[proc].position]-=1;
                }
                else if ((p[proc].state == READY && p->CPU!=proc) || (p[proc].state == BLCK && front(Block)!=proc))
                {
                    strcat(line,"READY     ");
                }
                else if (front(Block) == proc)
                {
                    strcat(line,"BLCK      ");
                    p[proc].state == BLCK;
                    p[proc].all_times[p[proc].position]-=1;
                }
                
            }
            else if (p[proc].state == EXIT)
            {
                strcat(line,"          ");
            }
            else if (p[proc].state != EXIT)
            {
                p[proc].state=EXIT;
                strcat(line,"EXIT      ");
            }
            
        }

    }
    
    return line;
}

int main(){

    int programas[3][8] = {
        {1, 3, 1, 2, 2, 4, 0, 0 } ,
        {1, 4, 2, 4, 1, 3, 0, 0 } ,
        {3, 2, 1, 6, 1, 3, 0, 0 } };

    int time=1;
    int number_of_process=(int)(sizeof(programas) / sizeof(programas[0]));

    PROCESS* p=malloc(number_of_process*sizeof*p);
    p->CPU=-5;     // indica que nenhum processo esta a ser corrido

    Queue B = createQueue(number_of_process);
    Queue R = createQueue(number_of_process);

    processStart(programas,number_of_process,p);
    processTimes(programas,number_of_process,p);                       

    for (int i = 0; i < number_of_process; i++)
        p[i].position=0;
    
    printf("\n");
    printf(" --------SIMULADOR DE ESCALONAMENTO FCFS------  \n");
    printf("\n");
    
    printf("instante ");
    for (int proc_num = 1; proc_num <= number_of_process; proc_num++)
        printf("|  proc%d  ",proc_num);            

    printf("\n");

    while (!isExited(p,number_of_process))         //time!=37 
    {
        printf("%d",time);
        if (time<10)
        {
            printf("            %s", algo_FCFS(time-1,number_of_process,B,R,p));
        }
        else
            printf("           %s", algo_FCFS(time-1,number_of_process,B,R,p));
        
        printf("\n");
        
        time++;    
    }

    makeEmpty(B);
    makeEmpty(R);
    
    return 0;
}