package com.example.playpal

class User(
    val id: Int = 0,
    val username: String = "",
    val password: String = "",
    val location: String = "",
    val sportInterest: String = ""
) {

    override fun toString(): String {
        return "User(id=$id, username='$username', password='$password', location='$location', sportInterest='$sportInterest')"
    }
}
