package com.example.playpal

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.playpal.databinding.ActivityShowgamesBinding

class   ShowGamesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityShowgamesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShowgamesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Data from intents
        val location = intent.getStringExtra("location")
        val sport = intent.getStringExtra("sport")

        // Fetch games
        val gamesList = fetchGames(location, sport)

        displayGames(gamesList)

        // Return button
        binding.goBackButton.setOnClickListener {
            finish()
        }
    }

    private fun fetchGames(location: String?, sport: String?): List<Game> {
        return GameStorage.getGames(location, sport)
    }

    private fun displayGames(gamesList: List<Game>) {
        val gamesText = gamesList.joinToString("\n") { game ->
            "Location: ${game.location}, Sport: ${game.sport}, Date: ${game.date}, Time: ${game.time}"
        }
        binding.tvGamesList.text = gamesText
    }
}
