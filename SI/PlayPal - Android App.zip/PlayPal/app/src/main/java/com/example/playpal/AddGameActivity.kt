package com.example.playpal

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.playpal.databinding.ActivityAddgameBinding

class AddGameActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddgameBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAddgameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Locations spinner
        val locations = arrayOf("Select a location", "Amadora", "Almada", "Braga", "Cascais", "Coimbra", "Évora", "Guimarães", "Leiria", "Lisboa", "Matosinhos", "Odivelas", "Portimão", "Porto", "Santarém", "Setúbal", "Vila Franca de Xira", "Vila Nova de Gaia", "Viseu")
        val locationAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, locations)
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.location.adapter = locationAdapter

        // Sports spinner
        val sports = arrayOf("Select a sport", "Futebol", "Futsal", "Padel", "Basquetebol", "Voleibol", "Corrida", "Ténis")
        val sportAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sports)
        sportAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.sport.adapter = sportAdapter

        // AddGame button
        binding.addGame.setOnClickListener {
            val location = binding.location.selectedItem.toString()
            val sport = binding.sport.selectedItem.toString()
            val date = binding.dateAdd.text.toString()
            val time = binding.timeAdd.text.toString()

            if (location == "Select a location" || sport == "Select a sport" || date.isEmpty() || time.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val game = Game(location, sport, date, time)
            GameStorage.addGame(game)

            Toast.makeText(
                this,
                "Game added: $sport at $location on $date at $time",
                Toast.LENGTH_LONG
            ).show()
        }

        // Return button
        binding.goBackButton.setOnClickListener {
            finish()
        }
    }
}
