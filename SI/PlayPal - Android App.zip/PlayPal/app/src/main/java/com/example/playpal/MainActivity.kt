package com.example.playpal

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.playpal.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Locations spinner
        val locations = arrayOf("Select a location: ", "Amadora", "Almada", "Braga", "Cascais", "Coimbra", "Évora", "Guimarães", "Leiria", "Lisboa", "Matosinhos", "Odivelas", "Portimão", "Porto", "Santarém", "Setúbal", "Vila Franca de Xira", "Vila Nova de Gaia", "Viseu")
        val locationAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, locations)
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerLocation.adapter = locationAdapter

        // Sports spinner
        val sports = arrayOf("Select a sport: ", "Futebol", "Futsal", "Padel", "Basquetebol", "Voleibol", "Corrida", "Ténis")
        val sportAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sports)
        sportAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerSport.adapter = sportAdapter

        binding.buttonSearch.setOnClickListener {
            val selectedLocation = binding.spinnerLocation.selectedItem.toString()
            val selectedSport = binding.spinnerSport.selectedItem.toString()

            val intent = Intent(this, ShowGamesActivity::class.java).apply {
                putExtra("location", selectedLocation)
                putExtra("sport", selectedSport)
            }
            startActivity(intent)
        }

        binding.buttonCreateEvent.setOnClickListener {
            val intent = Intent(this, AddGameActivity::class.java)
            startActivity(intent)
        }
    }
}
