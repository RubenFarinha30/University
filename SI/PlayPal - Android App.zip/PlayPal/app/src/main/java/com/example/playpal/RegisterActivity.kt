package com.example.playpal

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.playpal.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var dbHelper: DBLogin

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DBLogin(this)

        binding.registerButton.setOnClickListener {
            val username = binding.username.text.toString().trim()
            val password = binding.password.text.toString().trim()
            val location = binding.location.text.toString().trim()
            val sportInterest = binding.sportInterest.text.toString().trim()

            if (username.isEmpty() || password.isEmpty() || location.isEmpty() || sportInterest.isEmpty()) {
                showError("All fields are required")
            } else {
                val userId = dbHelper.selectByName(username)
                if (userId != 0) {
                    showError("Username already exists")
                } else {
                    val result = dbHelper.userInsert(username, password, location, sportInterest)
                    if (result > 0) {
                        Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        showError("Registration failed")
                    }
                }
            }
        }

        binding.goBackButton.setOnClickListener {
            finish()
        }
    }

    private fun showError(message: String) {
        binding.erro.text = message
        binding.erro.visibility = View.VISIBLE
    }
}
