package com.example.playpal

object GameStorage {
    private val games = mutableListOf<Game>()

    fun addGame(game: Game) {
        games.add(game)
    }

    fun getGames(location: String?, sport: String?): List<Game> {
        return games.filter {
            (location == null || it.location == location) &&
                    (sport == null || it.sport == sport)
        }
    }
}

data class Game(val location: String, val sport: String, val date: String, val time: String)
