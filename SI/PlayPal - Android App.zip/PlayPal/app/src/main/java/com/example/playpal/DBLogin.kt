package com.example.playpal

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DBLogin(context: Context) : SQLiteOpenHelper(context, "login.db", null, 1) {

    private val sql = arrayOf(
        "CREATE TABLE user (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, location TEXT, sportInterest TEXT)",
        "INSERT INTO user (username, password, location, sportInterest) VALUES ('admin', 'pwd', 'Unknown', 'None')",
        "INSERT INTO user (username, password, location, sportInterest) VALUES ('user', 'pass', 'Unknown', 'None')"
    )

    override fun onCreate(db: SQLiteDatabase) {
        sql.forEach {
            db.execSQL(it)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS user")
        onCreate(db)
    }

    fun userInsert(username: String, password: String, location: String, sportInterest: String): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("username", username)
            put("password", password)
            put("location", location)
            put("sportInterest", sportInterest)
        }
        val res = db.insert("user", null, values)
        db.close()
        return res
    }

    fun userDelete(name: String): Int {
        val db = this.writableDatabase
        val res = db.delete("user", "username=?", arrayOf(name))
        db.close()
        return res
    }

    fun userselectAll(): Cursor {
        val db = this.readableDatabase
        val result = db.rawQuery("SELECT * FROM user", null)
        return result
    }

    fun userselectById(id: Int): Cursor {
        val db = this.readableDatabase
        val result = db.rawQuery("SELECT * FROM user WHERE id=?", arrayOf(id.toString()))
        return result
    }

    fun selectById(id: Int): User {
        val db = this.readableDatabase
        val result = db.rawQuery("SELECT * FROM user WHERE id=?", arrayOf(id.toString()))
        var user = User()

        if (result.count == 1) {
            result.moveToFirst()

            val idIndex = result.getColumnIndex("id")
            val userIndex = result.getColumnIndex("username")
            val passIndex = result.getColumnIndex("password")
            val locationIndex = result.getColumnIndex("location")
            val sportIndex = result.getColumnIndex("sportInterest")

            val id = result.getInt(idIndex)
            val username = result.getString(userIndex)
            val password = result.getString(passIndex)
            val location = result.getString(locationIndex)
            val sportInterest = result.getString(sportIndex)

            user = User(id, username, password, location, sportInterest)
        }
        result.close()
        db.close()
        return user
    }

    fun selectByName(name: String): Int {
        val db = this.readableDatabase
        val result = db.rawQuery("SELECT * FROM user WHERE username=?", arrayOf(name))
        var finalID = 0
        Log.d("RESULTCOUNT", result.count.toString())
        if (result.count == 1) {
            result.moveToFirst()
            Log.d("ENTROU", "ENTROU")
            val idIndex = result.getColumnIndex("id")
            val id = result.getInt(idIndex)
            Log.d("FINALID", id.toString())
            finalID = id
        }
        result.close()
        db.close()
        return finalID
    }

    fun selectAll(): ArrayList<User> {
        val db = this.readableDatabase
        val result = db.rawQuery("SELECT * FROM user", null)
        val resultList: ArrayList<User> = ArrayList()

        if (result.count > 0) {
            result.moveToFirst()
            do {
                val idIndex = result.getColumnIndex("id")
                val userIndex = result.getColumnIndex("username")
                val passIndex = result.getColumnIndex("password")
                val locationIndex = result.getColumnIndex("location")
                val sportIndex = result.getColumnIndex("sportInterest")

                val id = result.getInt(idIndex)
                val username = result.getString(userIndex)
                val password = result.getString(passIndex)
                val location = result.getString(locationIndex)
                val sportInterest = result.getString(sportIndex)

                resultList.add(User(id, username, password, location, sportInterest))

            } while (result.moveToNext())
        }
        result.close()
        db.close()

        return resultList
    }
}
