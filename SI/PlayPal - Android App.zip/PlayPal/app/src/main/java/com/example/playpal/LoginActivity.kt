package com.example.playpal

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.playpal.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    // View Binding instance
    private lateinit var binding: ActivityLoginBinding
    private lateinit var dbHelper: DBLogin

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // View Binding
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DBLogin(this)

        // Login button
        binding.loginButton.setOnClickListener {
            val username = binding.username.text.toString()
            val password = binding.password.text.toString()

            // Input validation
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Exit the listener if validation fails
            }

            // Authentication
            val userId = dbHelper.selectByName(username)
            if (userId > 0) {
                val user = dbHelper.selectById(userId)

                if (user != null && user.password == password) {
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()

                    // Main activity
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()

                } else {
                    Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }


        // Register button
        binding.registerButton.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
                startActivity(intent)
        }
    }
}
