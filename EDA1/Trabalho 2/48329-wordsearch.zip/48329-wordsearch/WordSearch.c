#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#define Max_word 50
#define FileNameSize 1024
#define Max_table 100


typedef struct wordnode
{
    char word[Max_word];
    struct wordnode *next;
} wordnode;

wordnode *htable[Max_table];

typedef struct prefnode
{
    char word[Max_word];
    struct prefnode *next;
} prefnode;

prefnode *preftable[Max_table];

FILE *fp;
int *Prime = 0;

// get the next prime number from the number of words given to use as hashtable size
int nextprime(int nwords){ 
    int prime, divx;

    if (nwords <= 1)
    {
        prime = 2;
        printf("Tamanho da hash table é 2");
    }

    // Loop to get the next prime number from the number of words given
    for (prime = nwords; prime < Max_word ; prime++)
    {
        int count = 0;
        for (divx = 1; divx <= prime; divx++)
        {
            if (prime%divx==0)
            {
                count++;
            }
        }
    if(count==2){
        //printf("Primo: %d\n", prime);
        break;
        }

    }

    return prime;
}

// Get the hash key value
unsigned int hash(char name[], int sizeprime){
    int length = strlen(name);
    unsigned int hash_value = 0;
    for (int i = 0; i < length; i++)
    {
        hash_value += name[i] * 401 * i;
        hash_value = (hash_value * name[i]);
    }
    return hash_value % sizeprime;
}

//Load the hashtable
void load_table(int *sizeprime){

    for (int i = 0; i <= sizeprime-1; i++)
    {
        htable[i] = NULL;       
    }
}

//Insert words in the table
bool insert_word(char name[], int index){
    if(htable[index] != NULL){
        int sizeprime = Prime - 1;
        //printf("%s nao entrou\n", name);
        for(int i = 0; i < sizeprime; i++){
            int new_index = (index + i * i)%sizeprime;
            if (htable[new_index] == NULL)
            {
                htable[new_index] = name;
                break;
            }
             
        }
        return false;
    }else{
        htable[index] = name;
    }
    return true;
}

//Print the table to terminal
void print_table(int primesize){
    for (int i = 0; i <= primesize-1; i++)
    {
        if (htable[i] == NULL)
        {
            printf("%i - NULL\n",i);
        }else{
            printf("%i - %s\n", i, htable[i]->word);
        }  
    }
}

//-----Not finished------
//get the prefixes from the words
void prefixes(char pword[]){
    char prefword[Max_word];
    prefword[0] = 0;
    int size = (int)strlen(pword);
    for (int i = 0; i < size; i++)
    {   
        strncat(prefword,&pword[i],1);
        //printf("%s\n", prefword);
    }
}

//-----Not finished------
//load the prefix table
void load_pretable(int *sizeprime){

    for (int i = 0; i <= sizeprime-1; i++)
    {
        preftable[i] = NULL;       
    }
}

//-----Not finished------
//print prefix table
void print_pretable(int primesize){
    for (int i = 0; i <= primesize-1; i++)
    {
        if (preftable[i] == NULL)
        {
            printf("%i - NULL\n",i);
        }else{
            printf("%i - %s\n", i, preftable[i]->word);
        }  
    }
}

// search a given word in the hashtable
bool SearchWord(char fw[]){
    int size = Prime - 1;
    int index = hash(fw, size);
    if(htable[index] != NULL){
        if (strcmp(htable[index]->word, fw) == 0){
            //printf("%s", fw);
            return true;
        }
        for (int i = 0; i < size; i++){
            int new_index = (index + i * i)%size;
            if (strcmp(htable[new_index]->word, fw) == 0){
                    //printf("%s\n", fw);
                    return true;
                }
            }
        //printf("Not found");
        return false;
        }
    //printf("Not found");
    return false;
    }


// Open file, load the data from the file into the hash tables and the matrix for the Wordsearch game
bool OpLoadFile(const char *FileName){
    fp = fopen(FileName, "r");
    if (fp == NULL)
    {
        printf("Dictionary can not be opened.");
        return false;
    }
    int nwords = 0;
    fscanf(fp, "%d", &nwords);                      // scanning number of words to put in the hashtable
//    printf("Number of words: %d\n", nwords);
    Prime = nextprime(nwords);
    char word[Max_word];
    unsigned int hash_value = 0;

    load_table(Prime);

    fgets(word, Max_word, fp);  
    fgets(word, Max_word, fp);                      //skipping the empty lines/"\n"'s

    load_pretable(Prime);

    //Words to go into the hashtable
    for(int c = 0; c < nwords; c++){
        fgets(word, Max_word, fp);
        word[strcspn(word, "\n")] = 0;
        wordnode *newword = malloc(sizeof(wordnode));
        hash_value = hash(word, Prime);
//        printf("%d - ", hash_value);
//        printf ("%s\n", word);
        prefixes(word);
        strcpy(newword->word, word);
        insert_word(newword->word, hash_value);
    }

    int line = 0;
    int col = 0;
    fscanf(fp, "%d", &line);                        //number of lines in the word search
    printf("Linhas: %d\n", line);
    fscanf(fp, "%d", &col);                         //number of columns in the word search
    printf("Colunas: %d\n", col);

    //Put the characters in a matrix
    char mchar[line][col][3];
    for (int i = 0; i < line; i++)
    {
        printf("%d ", i);
        for (int j = 0; j < col; j++)
        {
            fscanf(fp, "%s", mchar[i][j]);
            printf("| %s |", mchar[i][j]);          // Print the matrix
        }
        printf("\n");
    }
    //printf("\n");


    // Word searching directions, some problems/not finished

    //Direção 0 FEITO
    char wordf[Max_word];
    wordf[0] = 0;
    for (int i = 0; i < line; i++)
    {
        for (int j = 0; j < col; j++)
        {
            for (int j2 = j; j2 < col; j2++)
            {
                strncat(wordf, &mchar[i][j2], 1);
                if (SearchWord(wordf) == true)
                {
                    printf("%s encontrado na direção 0\n", wordf);
                }
                
            }
            memset(wordf, 0, sizeof wordf);
        }   
    }

    /*
    //Direção 1 
    for (int i = 0; i < line; i++)
    {
        for (int j = col-1; j >= 0; j--)
        {
            for (int i2 = i; i2 < line; i2++)
            {
                int i2 = i;
                int j2 = j;
                while (i2 < line && j2 >= 0)
                {
                    printf("|%d - %d", i2, j2);
                    strncat(wordf, &mchar[i2][j2], 1);
                    if (SearchWord(wordf) == true)
                    {
                    printf("%s encontrado na direção 1\n", wordf);
                    }
                    i2++;
                    j2--;
                }
                printf("\n");
                memset(wordf, 0, sizeof wordf);
            }   
        }
    }
   */

    //Direção 2 - FEITO
    for (int i = 0; i < col; i++)
    {
        for (int j = 0; j < line; j++)
        {
            for (int j2 = j; j2 < line; j2++)
            {
                strncat(wordf, &mchar[j2][i], 1);
                if (SearchWord(wordf) == true)
                {
                    printf("%s encontrado na direção 2\n", wordf);
                }
            }
            memset(wordf, 0, sizeof wordf);
        }   
    }

    /*
    //Direção 3  Nao acabado
    for (int i = 0; i < line; i++)
    {
        for (int j = col-1; j >= 0; j--)
        {
            for (int i2 = i; i2 < line; i2++)
            {
                int i2 = i;
                int j2 = j;
                while (i2 < line && j2 >= 0)
                {
                    strncat(wordf, &mchar[i2][j2], 1);
                    if (SearchWord(wordf) == true)
                    {
                    printf("%s encontrado na direção 3\n", wordf);
                    }
                    i2++;
                    j2--;
                }
                memset(wordf, 0, sizeof wordf);
            }   
        }
    } */
    

    //Direção 4 FEITO
    for (int i = 0; i < line; i++)
    {
        for (int j = col-1; j >= 0; j--)
        {
            for (int j2 = j; j2 >= 0; j2--)
            {
                strncat(wordf, &mchar[i][j2], 1);
                if (SearchWord(wordf) == true)
                {
                    printf("%s encontrado na direção 4\n", wordf);
                }
            }
            memset(wordf, 0, sizeof wordf);
        }   
    }

    /*

    //Direção 5  Nao acabado
    for (int i = 0; i < col; i++)
    {
        for (int j = line-1; j >= 0; j--)
        {
            for (int i2 = i; i2 < line; i2++)
            {
                int i2 = i;
                int j2 = j;
                while (i2 < col && j2 >= 0)
                {
                    strncat(wordf, &mchar[j2][i2], 1);
                    if (SearchWord(wordf) == true)
                    {
                    printf("%s encontrado na direção 5\n", wordf);
                    }
                    i2--;
                    j2++;
                }
                memset(wordf, 0, sizeof wordf);
            }   
        }
    } */

    //Direção 6 FEITO
    for (int i = 0; i < col; i++)
    {
        for (int j = line-1; j >= 0; j--)
        {
            for (int j2 = j; j2 >= 0; j2--)
            {
                strncat(wordf, &mchar[j2][i], 1);
                if (SearchWord(wordf) == true)
                {
                    printf("%s encontrado na direção 6\n", wordf);
                }
            }
            memset(wordf, 0, sizeof wordf);
        }   
    }

    /*

    //Direção 7   nao acabado
    for (int i = 0; i < col; i++)
    {
        for (int j = line-1; j >= 0; j--)
        {
            for (int i2 = i; i2 < line; i2++)
            {
                int i2 = i;
                int j2 = j;
                while (i2 < col && j2 >= 0)
                {
                    strncat(wordf, &mchar[j2][i2], 1);
                    if (SearchWord(wordf) == true)
                    {
                    printf("%s encontrado na direção 7\n", wordf);
                    }
                    i2--;
                    j2++;
                }
                memset(wordf, 0, sizeof wordf);
            }   
        }
    } */

    return true;
}



int main (){
    OpLoadFile("smallPuzzle.txt");
    //print_table(Prime);
    //print_pretable(Prime);
    //SearchWord("póvoa");
    
    return 0;
}