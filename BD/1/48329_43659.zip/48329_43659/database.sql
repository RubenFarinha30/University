-- TABLE
CREATE TABLE amigo(
	"IdMemb1" VARCHAR(50) REFERENCES membro("IdMemb"),
	"IdMemb2" VARCHAR(50) REFERENCES membro("IdMemb"),
	CONSTRAINT pk_amigo PRIMARY KEY("IdMemb1", "IdMemb2")
);
CREATE TABLE autor(
	"Coda" VARCHAR(50),
	"Nome" VARCHAR(100),
	"País" VARCHAR(50),
	CONSTRAINT pk_autor PRIMARY KEY("Coda")
);
CREATE TABLE autoria(
	"ISBN" CHAR(13) REFERENCES livro("ISBN"),
	"Coda" VARCHAR(50) REFERENCES autor("Coda"),
	CONSTRAINT pk_autoria PRIMARY KEY ("ISBN", "Coda")
);
CREATE TABLE genero(
	"ISBN" CHAR(13) REFERENCES livro("ISBN"),
	"Genero" VARCHAR(100),
	CONSTRAINT pk_genero PRIMARY KEY ("ISBN", "Genero")
);
CREATE TABLE gosta(
	"IdMemb" VARCHAR(50) REFERENCES membro("IdMemb"),
	"ISBN" CHAR(13) REFERENCES livro("ISBN"),
	CONSTRAINT pk_gosta PRIMARY KEY("IdMemb", "ISBN")
);
CREATE TABLE leu(
	"IdMemb" VARCHAR(50) REFERENCES membro("IdMemb"),
	"ISBN" CHAR(13) REFERENCES livro("ISBN"),
	CONSTRAINT pk_leu PRIMARY KEY("IdMemb", "ISBN")
);
CREATE TABLE livro(
	"ISBN" CHAR(13),
	"Título" VARCHAR(200),
	CONSTRAINT pk_livro PRIMARY KEY("ISBN")
);
CREATE TABLE membro(
	"Nome" VARCHAR(100),
	"IdMemb" VARCHAR(50),
	"Pais" VARCHAR(50),
	CONSTRAINT pk_membro PRIMARY KEY("IdMemb")
);
 
-- INDEX
 
-- TRIGGER
 
-- VIEW
 
