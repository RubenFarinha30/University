package trabalhofinal;

import java.util.ArrayList;

public class Restaurante {
	
	String nome;
	String local;
	String categoria;
	ArrayList<Menu> Menu = new ArrayList<Menu>();
	ArrayList<artigo> artigo = new ArrayList<artigo>();
	
	public Restaurante(String nome, String local, String categoria, ArrayList<Menu> Menu, ArrayList<artigo> artigo) {
		this.nome = nome;
        this.local = local;
        this.categoria = categoria;
        this.Menu = Menu;
        this.artigo = artigo;
	}
	
    public String getNome() {
        return nome;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getLocal() {
        return local;
    }
    
    public void setLocal(String local) {
        this.local = local;
    }
    
    public String getCategoria() {
        return categoria;
    }
    
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    public ArrayList<Menu> getMenu() {
        return Menu;
    }

    public void setMenu(ArrayList<Menu> Menu) {
        this.Menu = Menu;
    }
    
    public ArrayList<artigo> getArtigo() {
        return artigo;
    }

    public void setArtigo(ArrayList<artigo> artigo) {
        this.artigo = artigo;
    }
}
