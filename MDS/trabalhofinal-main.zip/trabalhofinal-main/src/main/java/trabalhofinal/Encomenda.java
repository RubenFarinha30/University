package trabalhofinal;

public class Encomenda {
    private cliente cliente;
    private Restaurante restaurante;
    private Menu menu;
    private artigo artigo;

    public Encomenda(cliente cliente, Restaurante restaurante, Menu menu, artigo artigo) {
        this.cliente = cliente;
        this.restaurante = restaurante;
        this.menu = menu;
        this.artigo = artigo;
    }

    public cliente getcliente() {
        return cliente;
    }

    public void setcliente(cliente cliente) {
        this.cliente = cliente;
    }

    public Restaurante getRestaurante() {
        return restaurante;
    }

    public void setRestaurante(Restaurante restaurante) {
        this.restaurante = restaurante;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public artigo getartigo() {
        return artigo;
    }

    public void setartigo(artigo artigo) {
        this.artigo = artigo;
    }
}
