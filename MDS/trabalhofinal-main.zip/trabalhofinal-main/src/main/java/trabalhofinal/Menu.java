package trabalhofinal;

import java.util.ArrayList;

public class Menu {
	private String nome;
	private float preco;
	ArrayList<artigo> artigo = new ArrayList<artigo>();
	
	public Menu(String nome, float d, ArrayList<artigo> artigo) {
		this.nome = nome;
		this.preco = d;
		this.artigo = artigo;
	}
	
    public String getNome() {
        return nome;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public float getPrice() {
        return preco;
    }

    public void setPrice(float preco) {
        this.preco = preco;
    }
    
    public ArrayList<artigo> getArtigo() {
        return artigo;
    }

    public void setArtigo(ArrayList<artigo> artigo) {
        this.artigo = artigo;
    }
}
