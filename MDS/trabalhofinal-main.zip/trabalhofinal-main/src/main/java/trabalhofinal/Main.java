package trabalhofinal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {
	
	public static List<cliente> listaclientes = new ArrayList<cliente>();
	public static List<Restaurante> listarestaurantes = new ArrayList<Restaurante>();

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
        boolean MenuInicio = true;
		
		System.out.print("----------------------------\n");
		System.out.print("Sistema de Entrega de Comida\n");
		System.out.print("----------------------------\n");
		
		while(MenuInicio) {
			System.out.println("-------->Menu<--------");
			System.out.println("1. Gestão Clientes");
			System.out.println("2. Gestão Restaurantes");
			System.out.println("3. Pesquisar");
			System.out.println("4. Efetuar encomenda");
			System.out.println("5. Sair.");
			System.out.println("Insira opção(#): ");
			System.out.println("----------------------");
			int escolha = scanner.nextInt();
			
			switch (escolha) {
				case 1:
					boolean GestaoCliente = true;
						while (GestaoCliente) {
							System.out.println("----------------------");
							System.out.println("->Gestão Clientes:");
	                        System.out.println("1. Criar Cliente");
	                        System.out.println("2. Editar Cliente");
	                        System.out.println("3. Eliminar Cliente");
	                        System.out.println("4. Voltar ao Menu Inicio");
	                        System.out.print("Insira opção(#): ");
	                        System.out.println("----------------------");
	                        int escolhacliente = scanner.nextInt();
	                        
	                        switch (escolhacliente) {
	                        	case 1:
	                        		System.out.println("->1. Criar Cliente");
	                        		CreateCliente(scanner);
	                        		GestaoCliente = false;
	                        		break;
	                        	case 2:
	                        		System.out.println("->2. Editar Cliente");
	                        		UpdateCliente(scanner);
	                        		GestaoCliente = false;
	                        		break;
	                        	case 3:
	                        		System.out.println("->3. Eliminar Cliente");
	                        		DeleteCliente(scanner);
	                        		GestaoCliente = false;
	                        		break;
	                        	case 4:
	                        		MenuInicio = true;
	                        		GestaoCliente = false;
	                        		break;
	                        	default:
	                        		System.out.println("Escolha inválida");
	                        		break;
	                        }
						}
					break;
				case 2:
					boolean GestaoRestaurante = true;
						while (GestaoRestaurante) {
							System.out.println("----------------------");
							System.out.println("->Gestão Restaurantes:");
	                        System.out.println("1. Criar Restaurante");
	                        System.out.println("2. Editar Restaurante");
	                        System.out.println("3. Eliminar Restaurante");
	                        System.out.println("4. Voltar ao Menu Inicio");
	                        System.out.println("Insira opção(#): ");
	                        System.out.println("----------------------");
	                        int opcaorestaurante = scanner.nextInt();
	                        
	                        switch (opcaorestaurante) {
	                        	case 1:
	                        		System.out.println("->1. Criar Restaurante");
	                        		CreateRestaurante(scanner);
	                        		GestaoRestaurante = false;
	                        		break;
	                        	case 2:
	                        		System.out.println("->2. Editar Restaurante");
	                        			boolean edicaorestaurante = true;
	                        				while (edicaorestaurante) {
	                        					System.out.println("----------------------");
			        							System.out.println("->Gestão Restaurante:");
			        							System.out.println("1.Adicionar Artigos:");
			        							System.out.println("2.Eliminar Artigos:");
			        							System.out.println("3.Adicionar/Criar Menus:");
			        							System.out.println("4.Eliminar Menus:");
			        							System.out.println("5.Atualizar dados do Restaurante:");
			        							System.out.println("6.Voltar atrás:");
			        							System.out.println("Insira opção(#): ");
			        							System.out.println("----------------------");
			        							int opcaoedit = scanner.nextInt();
			        							
			        							switch (opcaoedit) {
				        							case 1:
			        									System.out.println("->1. Adicionar Artigos:");
			        									AddArtigo(scanner);
			        	        						edicaorestaurante = false;
			        									break;
			        								case 2:
			        									System.out.println("->2.Eliminar Artigos:");
			        									scanner.nextLine();
			        									System.out.println("Qual é o nome do Restaurante?");
			        									String nomerestaurante = scanner.nextLine();
			        									System.out.println("Qual é o nome do Artigo?");
			        									String nomeartigo = scanner.nextLine();
			        									RemoveArtigo(nomerestaurante, nomeartigo);
			        									edicaorestaurante = false;
			        									break;
			        								case 3:
			        									System.out.println("->3.Adicionar/Criar Menus:");
			        									AddMenu(scanner);
			        									edicaorestaurante = false;
			        									break;
			        								case 4:
			        									System.out.println("->4.Eliminar Menus:");
			        									RemoveMenu(scanner);
			        									edicaorestaurante = false;
			        									break;			
			        								case 5:
			        									System.out.println("->5.Atualizar dados do Restaurante:");
			        									UpdateRestaurante(scanner);
			        									edicaorestaurante = false;
			        									break;
			        								case 6:
			        									GestaoRestaurante = true;
			        									edicaorestaurante = false;
			        									break;
			        								default:
			        									System.out.println("Escolha inválida");
			        									break;
			        							}
	                        				}
	                        		break;
	                        	case 3:
	                        		System.out.println("->3. Eliminar Restaurante");
	                        		DeleteRestaurante(scanner);
	                        		GestaoRestaurante = false;
	                        		break;
	                        	case 4:
	                        		MenuInicio = true;
	                        		GestaoRestaurante = false;
	                        		break;
	                        	default:
	                        		System.out.println("Escolha inválida");
	                        		break;
	                        }
						}
					break;
				case 3:
					System.out.println("->Pesquisar<-");
					MenuInicio = false;
					break;
				case 4:
					System.out.println("->Efetuar encomenda<-");
					MenuInicio = false;
					break;
				case 5:
					System.out.println("->End.<-");
					MenuInicio = false;
					break;
				default:
					System.out.println("Escolha inválida");
					break;
			}
		}
		scanner.close();
	}
	
	// -------Gestão Clientes----------
	
	
	// Create new Cliente
	
	
	
	public static void CreateCliente(Scanner scanner) {
		
		scanner.nextLine();
		System.out.println("Enter cliente name: ");
        String nomecliente = scanner.nextLine();
        System.out.println("Enter cliente address: ");
        String morada = scanner.nextLine();
        
        cliente novocliente = new cliente(nomecliente, morada);
        listaclientes.add(novocliente);
        for (cliente icliente: listaclientes) {
        	System.out.println(icliente.getNome() + icliente.getMorada());
        }
	}
	
	
	// Update existing cliente details
	
	
	public static void UpdateCliente(Scanner scanner) {
		
		scanner.nextLine();
		System.out.println("Qual é o nome do cliente a editar:");
		String nomecliente = scanner.nextLine();
		for (cliente i: listaclientes) {
			if(i.getNome().equals(nomecliente)) {
				System.out.println("Enter cliente name: ");
		        String newnomecliente = scanner.nextLine();
		        System.out.println("Enter cliente address: ");
		        String newmorada = scanner.nextLine();
		        i.setMorada(newmorada);
		        i.setNome(newnomecliente);
			}else{
				System.out.println("Não foi possível encontrar o cliente");
			}
		}
	}
	
	
	// Delete existing cliente
	
	
	public static void DeleteCliente(Scanner scanner) {
		
		scanner.nextLine();
		System.out.println("Qual é o nome do cliente a eliminar:");
		String nomecliente = scanner.nextLine();
		Iterator<cliente> it = listaclientes.iterator();
		while(it.hasNext()) {
			String enomes = it.next().getNome();
			if(enomes.equals(nomecliente)) {
				it.remove();
				System.out.println("Removido com sucesso");
			}else {
				System.out.println("Nao encontrado");
			}
		}
	}
	
	// -------Gestão Restaurantes----------
	
	
	// Create new Restaurante
	
	
	public static void CreateRestaurante(Scanner scanner) {
		
		scanner.nextLine();
		System.out.println("Insira o nome do restaurante: ");
        String nomerestaurante = scanner.nextLine();
        System.out.println("Insira a morada do restaurante: ");
        String morada = scanner.nextLine();
        System.out.println("Insira a categoria do restaurante: ");
        String categoria = scanner.nextLine();
        ArrayList<Menu> menus = new ArrayList<Menu>();
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        
        Restaurante novorestaurante = new Restaurante(nomerestaurante, morada, categoria, menus, artigos);
        listarestaurantes.add(novorestaurante);
        for (Restaurante i: listarestaurantes) {
        	System.out.println(i.getNome() + i.getLocal() + i.getCategoria() + i.getMenu() + i.getArtigo());
        }
	}
	
	
	// Update existing Restaurant details
	
	
	public static void UpdateRestaurante(Scanner scanner) {
		
		scanner.nextLine();
		System.out.println("Qual é o nome do restaurante a editar:");
		String restaurante = scanner.nextLine();
		for (Restaurante i: listarestaurantes) {
			if(i.getNome().equals(restaurante)) {
				System.out.println("Insira o novo nome: ");
		        String newrestaurante = scanner.nextLine();
		        System.out.println("Insira a nova morada: ");
		        String morada = scanner.nextLine();
                System.out.println("Insira a nova categoria: ");
		        String categoria = scanner.nextLine();
		        i.setLocal(morada);
		        i.setNome(newrestaurante);
                i.setCategoria(categoria);
			}else{
				System.out.println("Não foi possível encontrar o restaurante");
			}
		}
	}
	
	
	// Deleting existing Restaurant
	
	
	public static void DeleteRestaurante(Scanner scanner) {
		
		scanner.nextLine();
		System.out.println("Qual é o nome do restaurante a eliminar:");
		String nomerestaurante = scanner.nextLine();
		Iterator<Restaurante> it = listarestaurantes.iterator();
		while(it.hasNext()){
			String rnomes = it.next().getNome();
			if(rnomes.equals(nomerestaurante)){
				it.remove();
				System.out.println("Removido com sucesso");				
			}else{
				System.out.println("Nao encontrado");
			}
		}
	}
	
	
	// -------------- Gestão Artigos -----------------


	public static void AddArtigo(Scanner scanner) {
		
		scanner.nextLine();
		System.out.println("Qual é o nome do restaurante:");
		String nomerestaurante = scanner.nextLine();
		Iterator<Restaurante> it = listarestaurantes.iterator();
		while(it.hasNext()){
			Restaurante restaurantes = it.next();
			if(restaurantes.getNome().equals(nomerestaurante)){
				System.out.println("Insira o nome do Artigo");
				String nomeartigo = scanner.nextLine();
				System.out.println("Insira o preço do Artigo");
				double preco = scanner.nextDouble();
				System.out.println("Insira a categoria do Artigo");
				String categoria = scanner.nextLine();
				System.out.println("Insira a descrição do Artigo");
				String descricao = scanner.nextLine();
				artigo novoartigo = new artigo(nomeartigo, preco, categoria, descricao);
				restaurantes.artigo.add(novoartigo);
				
			}else{
				System.out.println("Nao encontrado");
			}
		}
	}
	
	public static void RemoveArtigo(String nomerestaurante, String nomeartigo) {
		
		Iterator<Restaurante> it = listarestaurantes.iterator();
		while(it.hasNext()){
			Restaurante restaurantes = it.next();
			if(restaurantes.getNome().equals(nomerestaurante)){
				Iterator<artigo> artigoit = restaurantes.artigo.iterator();
				while(artigoit.hasNext()) {
					artigo artigos = artigoit.next();
					if(artigos.getNome().equals(nomeartigo)){
						restaurantes.artigo.remove(artigos);
					}else {
						System.out.println("Artigo não encontrado.");
					}
				}
			}else {
			System.out.println("Restaurante não encontrado.");
			}
		}
	}
	
	public static void AddMenu(Scanner scanner) {
		
		scanner.nextLine();
		System.out.println("Qual é o nome do restaurante:");
		String nomerestaurante = scanner.nextLine();
		Iterator<Restaurante> it = listarestaurantes.iterator();
		while(it.hasNext()){
			Restaurante restaurantes = it.next();
			if(restaurantes.getNome().equals(nomerestaurante)){
				System.out.println("Insira o nome do Menu");
				String nomeMenu = scanner.nextLine();
				System.out.println("Insira o preco do Menu");
				float precoMenu = scanner.nextFloat();
				ArrayList<artigo> listartigo = new ArrayList<artigo>();
				ArrayList<Menu> listaMenus = new ArrayList<Menu>();
				boolean adicartigos = true;
				while(adicartigos) {
					System.out.println("Pretende adicionar artigos? (Sim/Nao)");
					String questionart = scanner.nextLine();
					if(questionart.equals("Sim")) {
						System.out.println("Qual o nome do artigo?");
						String nomeartigo = scanner.nextLine();
						Iterator<artigo> artigoit = restaurantes.artigo.iterator();
						while(artigoit.hasNext()) {
							artigo artigos = artigoit.next();
							if(artigos.getNome().equals(nomeartigo)){
								listartigo.add(artigos);
								Menu novomenu = new Menu(nomeMenu, precoMenu, listartigo);
								listaMenus.add(novomenu);
								restaurantes.setMenu(listaMenus);
							}else {
								System.out.println("Artigo não encontrado.");
							}
						}
						adicartigos = true;
					}else {
						adicartigos = false;
					}
				}
			}else{
				System.out.println("Nao encontrado");
			}
		}
	}
	
	public static void RemoveMenu(Scanner scanner) {
		
		scanner.nextLine();
		System.out.println("Qual é o nome do restaurante:");
		String nomerestaurante = scanner.nextLine();
		Iterator<Restaurante> it = listarestaurantes.iterator();
		while(it.hasNext()){
			Restaurante restaurantes = it.next();
			if(restaurantes.getNome().equals(nomerestaurante)){
				Iterator<Menu> MenuIT = restaurantes.Menu.iterator();
				System.out.println("Qual o nome do Menu que pretende remover?");
				String nomemenu = scanner.nextLine();
				while(MenuIT.hasNext()) {
					Menu menus = MenuIT.next();
					if(menus.getNome().equals(nomemenu)) {
						restaurantes.Menu.remove(menus);
					}else {
						System.out.println("Não foi possivel encontrar o menu");
					}
				}
			}else {
				System.out.println("Não foi possivel encontrar o Restaurante");
			}
		}
	}
}