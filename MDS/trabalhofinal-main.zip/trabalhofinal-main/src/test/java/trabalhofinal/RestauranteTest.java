package trabalhofinal;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import java.util.ArrayList;

public class RestauranteTest {
	
    @Test
    public void testNome() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, mozarela e manjericão"));
        artigos.add(new artigo("Coca-Cola", 3.50, "Bebida", "Refrigerante de cola"));
        ArrayList<Menu> menus = new ArrayList<Menu>();
        menus.add(new Menu("Menu da Pizza", (float) 16.00, artigos));
        menus.add(new Menu("Menu do Domingo", (float) 20.00, artigos));
        Restaurante restaurante = new Restaurante("Pizzaria Nonna", "Centro", "Pizzaria", menus, artigos);
        assertEquals("Pizzaria Nonna", restaurante.getNome());
    }
    
    @Test
    public void testLocal() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, mozarela e manjericão"));
        artigos.add(new artigo("Coca-Cola", 3.50, "Bebida", "Refrigerante de cola"));
        ArrayList<Menu> menus = new ArrayList<Menu>();
        menus.add(new Menu("Menu da Pizza", (float) 16.00, artigos));
        menus.add(new Menu("Menu do Domingo", (float) 20.00, artigos));
        Restaurante restaurante = new Restaurante("Pizzaria Nonna", "Centro", "Pizzaria", menus, artigos);
        assertEquals("Centro", restaurante.getLocal());
    }
    
    @Test
    public void testCategoria() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, mozarela e manjericão"));
        artigos.add(new artigo("Coca-Cola", 3.50, "Bebida", "Refrigerante de cola"));
        ArrayList<Menu> menus = new ArrayList<Menu>();
        menus.add(new Menu("Menu da Pizza", (float) 16.00, artigos));
        menus.add(new Menu("Menu do Domingo", (float) 20.00, artigos));
        Restaurante restaurante = new Restaurante("Pizzaria Nonna", "Centro", "Pizzaria", menus, artigos);
        assertEquals("Pizzaria Nonna", restaurante.getCategoria());
        }
    
    @Test
    public void testMenu() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, mozarela e manjericão"));
        artigos.add(new artigo("Coca-Cola", 3.50, "Bebida", "Refrigerante de cola"));
        ArrayList<Menu> menus = new ArrayList<Menu>();
        menus.add(new Menu("Menu da Pizza", (float) 16.00, artigos));
        menus.add(new Menu("Menu do Domingo", (float) 20.00, artigos));
        Restaurante restaurante = new Restaurante("Pizzaria Nonna", "Centro", "Pizzaria", menus, artigos);
        assertEquals(menus, restaurante.getMenu());
    }
    
    @Test
    public void testArtigo() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, mozarela e manjericão"));
        artigos.add(new artigo("Coca-Cola", 3.50, "Bebida", "Refrigerante de cola"));
        ArrayList<Menu> menus = new ArrayList<Menu>();
        menus.add(new Menu("Menu da Pizza", (float) 16.00, artigos));
        menus.add(new Menu("Menu do Domingo", (float) 20.00, artigos));
        Restaurante restaurante = new Restaurante("Pizzaria Nonna", "Centro", "Pizzaria", menus, artigos);
        assertEquals(artigos, restaurante.getArtigo());
        }

    @Test
    public void testSetNome() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, mozarela e manjericão"));
        artigos.add(new artigo("Coca-Cola", 3.50, "Bebida", "Refrigerante de cola"));
        ArrayList<Menu> menus = new ArrayList<Menu>();
        menus.add(new Menu("Menu da Pizza", (float) 16.00, artigos));
        menus.add(new Menu("Menu do Domingo", (float) 20.00, artigos));
        Restaurante restaurante = new Restaurante("Pizzaria Nonna", "Centro", "Pizzaria", menus, artigos);
        restaurante.setNome("Pizzaria do Porto");
        assertEquals("Pizzaria do Porto", restaurante.getNome());
    }
    
    @Test
    public void testSetLocal() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, mozarela e manjericão"));
        artigos.add(new artigo("Coca-Cola", 3.50, "Bebida", "Refrigerante de cola"));
        ArrayList<Menu> menus = new ArrayList<Menu>();
        menus.add(new Menu("Menu da Pizza", (float) 16.00, artigos));
        menus.add(new Menu("Menu do Domingo", (float) 20.00, artigos));
        Restaurante restaurante = new Restaurante("Pizzaria Nonna", "Centro", "Pizzaria", menus, artigos);
        restaurante.setLocal("Matosinhos");
        assertEquals("Matosinhos", restaurante.getLocal());
        }
    
    @Test
    public void testSetCategoria() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, mozarela e manjericão"));
        artigos.add(new artigo("Coca-Cola", 3.50, "Bebida", "Refrigerante de cola"));
        ArrayList<Menu> menus = new ArrayList<Menu>();
        menus.add(new Menu("Menu da Pizza", (float) 16.00, artigos));
        menus.add(new Menu("Menu do Domingo", (float) 20.00, artigos));
        Restaurante restaurante = new Restaurante("Pizzaria Nonna", "Centro", "Pizzaria", menus, artigos);
        restaurante.setCategoria("Comida Italiana");
        assertEquals("Comida Italiana", restaurante.getCategoria());
        }
    
    @Test
    public void testSetMenu() {
    	ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, mozarela e manjericão"));
        artigos.add(new artigo("Coca-Cola", 3.50, "Bebida", "Refrigerante de cola"));
        ArrayList<Menu> menus = new ArrayList<Menu>();
        menus.add(new Menu("Menu da Pizza", (float) 16.00, artigos));
        ArrayList<Menu> newMenus = new ArrayList<Menu>();
        newMenus.add(new Menu("Menu Especial", (float) 20.00, artigos));
        Restaurante restaurante = new Restaurante("Pizzaria Nonna", "Centro", "Pizzaria", menus, artigos);
        restaurante.setMenu(newMenus);
        assertEquals(newMenus, restaurante.getMenu());
    }
    
    @Test
    public void testSetArtigo() {
    	ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, mozarela e manjericão"));
        artigos.add(new artigo("Coca-Cola", 3.50, "Bebida", "Refrigerante de cola"));
        ArrayList<artigo> newArtigos = new ArrayList<artigo>();
        newArtigos.add(new artigo("Pizza Pepperoni", 14.00, "Pizzas", "Pizza de pepperoni, mozarela e tomate"));
        newArtigos.add(new artigo("Cerveja", 4.00, "Bebida", "Cerveja de trigo"));
    	ArrayList<Menu> menus = new ArrayList<Menu>();
        menus.add(new Menu("Menu da Pizza", (float) 16.00, artigos));
        Restaurante restaurante = new Restaurante("Pizzaria Nonna", "Centro", "Pizzaria", menus, artigos);
        restaurante.setArtigo(newArtigos);
        assertEquals(newArtigos, restaurante.getArtigo());
        }
}