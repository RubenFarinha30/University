package trabalhofinal;

import org.junit.Test;
import static org.junit.Assert.*;

public class ClienteTest {

    @Test
    public void testConstructor() {
        // cria uma nova instância da classe Cliente
        cliente cliente = new cliente("João Silva", "Rua das Flores, 123");

        // verifica se os valores passados são armazenados corretamente nos atributos nome e morada
        assertEquals("João Silva", cliente.getNome());
        assertEquals("Rua das Flores, 123", cliente.getMorada());
    }

    @Test
    public void testGetNome() {
        // cria uma nova instância da classe Cliente
        cliente cliente = new cliente("João Silva", "Rua das Flores, 123");

        // verifica se o método getNome retorna o valor esperado
        assertEquals("João Silva", cliente.getNome());
    }

    @Test
    public void testSetNome() {
        // cria uma nova instância da classe Cliente
        cliente cliente = new cliente("João Silva", "Rua das Flores, 123");

        // define um novo valor para o atributo nome
        cliente.setNome("Maria Silva");

        // verifica se o método getNome retorna o novo valor
        assertEquals("Maria Silva", cliente.getNome());
    }

    @Test
    public void testGetMorada() {
        // cria uma nova instância da classe Cliente
        cliente cliente = new cliente("João Silva", "Rua das Flores, 123");

        // verifica se o método getMorada retorna o valor esperado
        assertEquals("Rua das Flores, 123", cliente.getMorada());
    }

    @Test
    public void testSetMorada() {
        // cria uma nova instância da classe Cliente
        cliente cliente = new cliente("João Silva", "Rua das Flores, 123");

        // define um novo valor para o atributo morada
        cliente.setMorada("Rua das Rosas, 456");

        // verifica se o método getMorada retorna o novo valor
        assertEquals("Rua das Rosas, 456", cliente.getMorada());
    }
}