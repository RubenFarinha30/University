package trabalhofinal;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class artigoTest {
    @Test
    public void testNome() {
        artigo artigo = new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, queijo mozarela e manjericão");
        assertEquals("Pizza Margherita", artigo.getNome());
    }

    @Test
    public void testPreco() {
        artigo artigo = new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, queijo mozarela e manjericão");
        assertEquals(12.50, artigo.getPreco(), 0.01);
    }

    @Test
    public void testCategoria() {
        artigo artigo = new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, queijo mozarela e manjericão");
        assertEquals("Pizzas", artigo.getCategoria());
    }

    @Test
    public void testDescricao() {
        artigo artigo = new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, queijo mozarela e manjericão");
        assertEquals("Pizza de tomate, queijo mozarela e manjericão", artigo.getDescricao());
    }

    @Test
    public void testSetNome() {
        artigo artigo = new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, queijo mozarela e manjericão");
        artigo.setNome("Pizza Margherita com Bacon");
        assertEquals("Pizza Margherita com Bacon", artigo.getNome());
    }

    @Test
    public void testSetPreco() {
        artigo artigo = new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, queijo mozarela e manjericão");
        artigo.setPreco(15.50);
        assertEquals(15.50, artigo.getPreco(), 0.01);
    }

    @Test
    public void testSetCategoria() {
        artigo artigo = new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, queijo mozarela e manjericão");
        artigo.setCategoria("Comida Italiana");
        assertEquals("Comida Italiana", artigo.getCategoria());
    }

    @Test
    public void testSetDescricao() {
        artigo artigo = new artigo("Pizza Margherita", 12.50, "Pizzas", "Pizza de tomate, queijo mozarela e manjericão");
        artigo.setDescricao("Pizza de tomate, queijo mozarela, manjericão e bacon");
        assertEquals("Pizza de tomate, queijo mozarela, manjericão e bacon", artigo.getDescricao());
        }
    }
       
