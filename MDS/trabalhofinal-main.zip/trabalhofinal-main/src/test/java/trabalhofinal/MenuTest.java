package trabalhofinal;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import java.util.ArrayList;

public class MenuTest {
    @Test
    public void testNome() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Alimentação", "Pizza de tomate, mussarela e manjericão"));
        artigos.add(new artigo("Coca-cola", 3.50, "Bebida", "Refrigerante de cola"));
        Menu menu = new Menu("Menu da Pizza", (float) 16.00, artigos);
        assertEquals("Menu da Pizza", menu.getNome());
    }
    
    @Test
    public void testPreco() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Alimentação", "Pizza de tomate, mussarela e manjericão"));
        artigos.add(new artigo("Coca-cola", 3.50, "Bebida", "Refrigerante de cola"));
        Menu menu = new Menu("Menu da Pizza", (float) 16.00, artigos);
        assertEquals(16.00, menu.getPrice(), 0.01);
    }
    
    @Test
    public void testartigos() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Alimentação", "Pizza de tomate, mussarela e manjericão"));
        artigos.add(new artigo("Coca-cola", 3.50, "Bebida", "Refrigerante de cola"));
        Menu menu = new Menu("Menu da Pizza", (float) 16.00, artigos);
        assertEquals(artigos, menu.getArtigo());
        }
        
    @Test
    public void testSetNome() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Alimentação", "Pizza de tomate, mussarela e manjericão"));
        artigos.add(new artigo("Coca-cola", 3.50, "Bebida", "Refrigerante de cola"));
        Menu menu = new Menu("Menu da Pizza", (float) 16.00, artigos);
        menu.setNome("Menu da Pizza com Refrigerante");
        assertEquals("Menu da Pizza com Refrigerante", menu.getNome());
    }
    
    @Test
    public void testSetPreco() {
    ArrayList<artigo> artigos = new ArrayList<artigo>();
    artigos.add(new artigo("Pizza Margherita", 12.50, "Alimentação", "Pizza de tomate, mussarela e manjericão"));
    artigos.add(new artigo("Coca-cola", 3.50, "Bebida", "Refrigerante de cola"));
    Menu menu = new Menu("Menu da Pizza", (float) 16.00, artigos);
    menu.setPrice((float) 18.00);
    assertEquals(18.00, Menu.getPrice(), 0.01);
    }
    
    @Test
    public void testSetartigos() {
        ArrayList<artigo> artigos = new ArrayList<artigo>();
        artigos.add(new artigo("Pizza Margherita", 12.50, "Alimentação", "Pizza de tomate, mussarela e manjericão"));
        artigos.add(new artigo("Coca-cola", 3.50, "Bebida", "Refrigerante de cola"));
        Menu menu = new Menu("Menu da Pizza", (float) 16.00, artigos);
        ArrayList<artigo> novosartigos = new ArrayList<artigo>();
        novosartigos.add(new artigo("Pizza Pepperoni", 14.50, "Alimentação", "Pizza de pepperoni e mussarela"));
        novosartigos.add(new artigo("Água mineral", 2.50, "Bebida", "Água mineral sem gás"));
        menu.setArtigo(novosartigos);
        assertEquals(novosartigos, menu.getArtigo());
    }
}
        