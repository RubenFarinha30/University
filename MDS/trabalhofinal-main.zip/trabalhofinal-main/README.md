## Relatório de Trabalho - 2ª Parte

#### Classes

- Para melhorar a organização dos dados e armazenamento de informações relevantes, foram criadas classes específicas para a gestão de clientes, restaurantes, artigos e menus.
- A classe Main foi desenvolvida com diversos métodos que permitem a utilização e gestão dos objetos, além disso, foi implementado um menu intuitivo para facilitar a navegação do utilizador.
- A classe Restaurante tem como objetivo criar objetos que possuem atributos como nome, local, categoria e listas de artigos e menus, permitindo a gestão dessas informações.
- A classe cliente tem como objetivo criar objetos que possuem atributos como nome e localização, de forma a identificar unicamente cada cliente.
- A classe menu foi desenvolvida com atributos como nome, preço e uma lista de artigos, possibilitando a criação de conjuntos de artigos com um preço exclusivo e identificação única.
- A classe artigo foi criada com atributos como nome, preço, categoria e descrição, permitindo a identificação única de cada artigo e facilitando sua identificação.
- A criação de uma classe Encomenda, com atributos para armazenar informações sobre o cliente, o restaurante, o menu e os artigos selecionados, é necessário para garantir a existência de menus e artigos selecionados no restaurante específico associado à encomenda. Dessa forma, é possível criar encomendas personalizadas, vinculando um cliente específico e os itens de menu/artigos desejados de um restaurante específico.

#### Funções

- As funções CreateCliente, UpdateCliente e DeleteCliente foram desenvolvidas para gerir a classe cliente. A função CreateCliente tem como objetivo criar um novo objeto cliente, a função UpdateCliente tem como objetivo atualizar as informações de um objeto cliente já existente e a função DeleteCliente tem como objetivo excluir um objeto cliente já existente. Essas funções permitem a gestão completa dos clientes.
- As funções CreateRestaurante, UpdateRestaurante e DeleteRestaurante foram desenvolvidas para gerir a classe restaurante. A função CreateRestaurante tem como objetivo criar um novo objeto restaurante, a função UpdateRestaurante tem como objetivo atualizar as informações de um objeto restaurante já existente, incluindo a possibilidade de adicionar artigos e menus e a função DeleteRestaurante tem como objetivo excluir um objeto restaurante já existente. Essas funções permitem a gestão completa dos restaurantes.
- As funções AddArtigo, RemoveArtigo, AddMenu e RemoveMenu foram desenvolvidas para gerenciar a criação e remoção de itens de menu de um restaurante específico. Essas funções permitem aos usuários adicionar e remover artigos e menus de acordo com suas necessidades e preferencias.

#### Testes

- Inicialmente, foram implementados testes unitários para as classes Menu, Restaurante, Cliente e Artigo, para garantir a qualidade e correto funcionamento dessas classes. Esses testes permitem verificar se as funções e métodos estão a funcionar corretamente, e se os objetos estão sendo criados e manipulados da forma esperada.

#### Conclusão

- Não foi possivel terminar o trabalho ficando as funções de pesquisa e encomenda. A função de pesquisa deveria percorrer os restaurantes e artigos para encontrar os itens procurados, adicionando-os a uma lista pré-estabelecida e retornando-a. A função de encomenda, utilizando a função de pesquisa, permitiria adicionar a classe Encomenda, associando o cliente, o restaurante e os itens e menus específicos.

#### Linguagem
Java
###### Trabalho realido por: Ruben Farinha, nº 48329